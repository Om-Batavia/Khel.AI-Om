from schemas import RequiredRunRateRequest, RequiredRunRateResponse


def calculate_required_run_rate(payload: RequiredRunRateRequest) -> RequiredRunRateResponse:
    target = payload.innings.target or payload.match.target
    total_overs = payload.innings.total_overs_limit or payload.match.total_overs or 20
    total_runs = sum(_int(ball.runs_off_bat) + _int(ball.extras) for ball in payload.balls)
    legal_balls = sum(1 for ball in payload.balls if ball.is_legal_delivery)
    wickets = sum(1 for ball in payload.balls if ball.wicket_fell)
    total_balls = int(total_overs) * 6
    balls_remaining = max(total_balls - legal_balls, 0)

    if not target:
        return RequiredRunRateResponse(
            runs_needed=0,
            balls_remaining=balls_remaining,
            overs_remaining=_overs_display(balls_remaining),
            required_run_rate=0,
            target=None,
            current_score=f"{total_runs}/{wickets}",
            message="No chase target is available, so required run rate cannot be calculated.",
        )

    runs_needed = max(_int(target) - total_runs, 0)
    required_run_rate = round((runs_needed / balls_remaining) * 6, 2) if balls_remaining and runs_needed else 0

    if runs_needed == 0:
        message = "Target has already been reached."
    elif balls_remaining == 0:
        message = "No balls remaining in the chase."
    else:
        message = "Required run rate calculated from runs needed and balls remaining."

    return RequiredRunRateResponse(
        runs_needed=runs_needed,
        balls_remaining=balls_remaining,
        overs_remaining=_overs_display(balls_remaining),
        required_run_rate=required_run_rate,
        target=target,
        current_score=f"{total_runs}/{wickets}",
        message=message,
    )


def _overs_display(legal_balls):
    return f"{legal_balls // 6}.{legal_balls % 6}"


def _int(value):
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0
