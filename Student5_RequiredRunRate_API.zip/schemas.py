from typing import Optional

from pydantic import BaseModel, Field


class BallEvent(BaseModel):
    over_number: int
    ball_number: int
    runs_off_bat: int = 0
    extras: int = 0
    is_legal_delivery: bool = True
    wicket_fell: bool = False


class MatchInfo(BaseModel):
    title: Optional[str] = None
    total_overs: Optional[int] = Field(default=20, gt=0)
    target: Optional[int] = None


class InningsInfo(BaseModel):
    innings_number: Optional[int] = None
    total_overs_limit: Optional[int] = Field(default=None, gt=0)
    target: Optional[int] = None


class RequiredRunRateRequest(BaseModel):
    match: MatchInfo = Field(default_factory=MatchInfo)
    innings: InningsInfo = Field(default_factory=InningsInfo)
    balls: list[BallEvent] = Field(default_factory=list)


class RequiredRunRateResponse(BaseModel):
    runs_needed: int
    balls_remaining: int
    overs_remaining: str
    required_run_rate: float
    target: Optional[int] = None
    current_score: str
    message: str
