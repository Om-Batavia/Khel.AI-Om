# Student 5 - Required Run Rate API

## API Name
Required Run Rate API

## Objective
This API calculates the current chase requirement for Khel AI MVP. It accepts match, innings, and ball-by-ball payload data, then returns runs needed, balls remaining, overs remaining, required run rate, current score, target, and an explanatory message.

## Endpoint
```text
POST /student5/required-run-rate
```

## Run Locally
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Render Start Command
```bash
uvicorn main:app --host 0.0.0.0 --port $PORT
```

## Admin Handover
- Routes are in `main.py`.
- Request and response models are in `schemas.py`.
- Required run rate logic is in `services.py`.
- Use `sample_payload.json` to test the endpoint.
