from fastapi import FastAPI

from schemas import RequiredRunRateRequest, RequiredRunRateResponse
from services import calculate_required_run_rate


app = FastAPI(
    title="Student 5 - Required Run Rate API",
    description="Returns runs needed, balls remaining, and required run rate for a chase.",
)


@app.get("/")
def home():
    return {
        "api_name": "Required Run Rate API",
        "student": "Student 5",
        "endpoint": "/student5/required-run-rate",
    }


@app.post("/student5/required-run-rate", response_model=RequiredRunRateResponse)
def required_run_rate(payload: RequiredRunRateRequest):
    return calculate_required_run_rate(payload)
