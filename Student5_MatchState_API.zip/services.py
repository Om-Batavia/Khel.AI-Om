from schemas import MatchStateRequest, MatchStateResponse


def get_match_state(payload: MatchStateRequest) -> MatchStateResponse:
    target = payload.innings.target or payload.match.target
    total_overs = payload.innings.total_overs_limit or payload.match.total_overs or 20
    total_runs = sum(_int(ball.runs_off_bat) + _int(ball.extras) for ball in payload.balls)
    legal_balls = sum(1 for ball in payload.balls if ball.is_legal_delivery)
    wickets = sum(1 for ball in payload.balls if ball.wicket_fell)
    total_balls = int(total_overs) * 6
    balls_remaining = max(total_balls - legal_balls, 0)
    overs_completed = legal_balls / 6
    current_run_rate = round(total_runs / overs_completed, 2) if overs_completed else 0

    return MatchStateResponse(
        score=f"{total_runs}/{wickets}",
        runs=total_runs,
        wickets=wickets,
        overs=_overs_display(legal_balls),
        legal_balls=legal_balls,
        total_balls=total_balls,
        balls_remaining=balls_remaining,
        current_run_rate=current_run_rate,
        batting_team=payload.innings.batting_team,
        bowling_team=payload.innings.bowling_team,
        target=target,
        chase_status=_chase_status(total_runs, target, balls_remaining),
    )


def _chase_status(total_runs, target, balls_remaining):
    if not target:
        return "No target available"
    if total_runs >= target:
        return "Target reached"
    if balls_remaining == 0:
        return "Innings complete"
    return "Chase in progress"


def _overs_display(legal_balls):
    return f"{legal_balls // 6}.{legal_balls % 6}"


def _int(value):
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0
