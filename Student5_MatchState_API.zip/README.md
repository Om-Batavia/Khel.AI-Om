# Student 5 - Match State API

## API Name
Match State API

## Objective
This API returns the current match state for Khel AI MVP using real match, innings, and ball-by-ball payload data. It calculates score, wickets, overs, legal balls, balls remaining, current run rate, target, teams, and chase status in a stable frontend-ready JSON format.

## Endpoint
```text
POST /student5/match-state
```

## Run Locally
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Render Start Command
```bash
uvicorn main:app --host 0.0.0.0 --port $PORT
```

## Admin Handover
- Routes are in `main.py`.
- Request and response models are in `schemas.py`.
- Calculation logic is in `services.py`.
- Use `sample_payload.json` to test the endpoint.
