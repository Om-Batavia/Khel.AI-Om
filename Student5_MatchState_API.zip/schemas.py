from typing import Optional

from pydantic import BaseModel, Field


class BallEvent(BaseModel):
    over_number: int
    ball_number: int
    runs_off_bat: int = 0
    extras: int = 0
    is_legal_delivery: bool = True
    wicket_fell: bool = False


class MatchInfo(BaseModel):
    title: Optional[str] = None
    total_overs: Optional[int] = Field(default=20, gt=0)
    target: Optional[int] = None


class InningsInfo(BaseModel):
    innings_number: Optional[int] = None
    batting_team: Optional[str] = None
    bowling_team: Optional[str] = None
    total_overs_limit: Optional[int] = Field(default=None, gt=0)
    target: Optional[int] = None


class MatchStateRequest(BaseModel):
    match: MatchInfo = Field(default_factory=MatchInfo)
    innings: InningsInfo = Field(default_factory=InningsInfo)
    balls: list[BallEvent] = Field(default_factory=list)


class MatchStateResponse(BaseModel):
    score: str
    runs: int
    wickets: int
    overs: str
    legal_balls: int
    total_balls: int
    balls_remaining: int
    current_run_rate: float
    batting_team: Optional[str] = None
    bowling_team: Optional[str] = None
    target: Optional[int] = None
    chase_status: str
