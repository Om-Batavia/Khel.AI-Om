# Student 5 - Win Probability Label API

## API Name
Win Probability Label API

## Objective
This API provides a simple and explainable match-outlook label for a chasing cricket team. It uses the current chase state, including target, runs scored, wickets lost, legal balls, balls remaining, current run rate, and required run rate, then returns `High Chance`, `Medium Chance`, or `Low Chance` using a declared chase heuristic.

## Endpoint
```text
POST /student5/win-probability-label
```

## Run Locally
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Open:
```text
http://127.0.0.1:8000
http://127.0.0.1:8000/docs
```

## Sample Request
Use `sample_payload.json` as the request body.

```bash
curl -X POST "http://127.0.0.1:8000/student5/win-probability-label" ^
  -H "Content-Type: application/json" ^
  --data-binary "@sample_payload.json"
```

## Sample Response
```json
{
  "prediction": "High Chance",
  "label": "High Chance",
  "confidence_score": 75,
  "reason": "Required run rate is controlled compared with the current scoring rate and wickets in hand.",
  "rule": "High Chance when RRR <= current RR + 1.5 with at least 4 wickets left, or when <= 12 runs are needed with at least 12 balls left. Low Chance when RRR > current RR + 4, or when 2 or fewer wickets remain and more than 20 runs are needed. Otherwise Medium Chance.",
  "match_state": {
    "score": "12/1",
    "overs": "0.4",
    "target": 121,
    "balls_remaining": 116,
    "required_run_rate": 5.64
  },
  "inputs_used": {
    "runs_needed": 109,
    "wickets_remaining": 9,
    "current_run_rate": 18.0,
    "required_run_rate": 5.64
  }
}
```

## Declared Rule
The API returns `High Chance` when the required run rate is less than or equal to current run rate plus 1.5 with at least 4 wickets left, or when 12 or fewer runs are needed with at least 12 balls left and at least 3 wickets left.

The API returns `Low Chance` when the required run rate is more than current run rate plus 4, or when 2 or fewer wickets remain and more than 20 runs are still needed.

All other chase situations return `Medium Chance`. If no target is provided, the API returns a neutral `Medium Chance`.

## Render Deployment
Build command:
```bash
pip install -r requirements.txt
```

Start command:
```bash
uvicorn main:app --host 0.0.0.0 --port $PORT
```

## Admin Handover
- Main app file: `main.py`
- Request and response schemas: `schemas.py`
- Win probability calculation logic: `services.py`
- Sample test body: `sample_payload.json`
- Runtime file for Render: `runtime.txt`
- Dependencies: `requirements.txt`
