from typing import Optional

from pydantic import BaseModel, Field


class BallEvent(BaseModel):
    over_number: int
    ball_number: int
    runs_off_bat: int = 0
    extras: int = 0
    is_legal_delivery: bool = True
    wicket_fell: bool = False


class MatchInfo(BaseModel):
    title: Optional[str] = None
    total_overs: Optional[int] = Field(default=20, gt=0)
    target: Optional[int] = None


class InningsInfo(BaseModel):
    innings_number: Optional[int] = None
    total_overs_limit: Optional[int] = Field(default=None, gt=0)
    target: Optional[int] = None


class WinProbabilityRequest(BaseModel):
    match: MatchInfo = Field(default_factory=MatchInfo)
    innings: InningsInfo = Field(default_factory=InningsInfo)
    balls: list[BallEvent] = Field(default_factory=list)


class MatchState(BaseModel):
    score: str
    overs: str
    target: Optional[int] = None
    balls_remaining: int
    required_run_rate: Optional[float] = None


class InputsUsed(BaseModel):
    runs_needed: int
    wickets_remaining: int
    current_run_rate: float
    required_run_rate: float


class WinProbabilityResponse(BaseModel):
    prediction: str
    label: str
    confidence_score: int
    reason: str
    rule: str
    match_state: MatchState
    inputs_used: Optional[InputsUsed] = None
