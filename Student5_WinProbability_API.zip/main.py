from fastapi import FastAPI

from schemas import WinProbabilityRequest, WinProbabilityResponse
from services import calculate_win_probability_label


app = FastAPI(
    title="Student 5 - Win Probability Label API",
    description="Returns High Chance, Medium Chance, or Low Chance using a simple chase heuristic.",
)


@app.get("/")
def home():
    return {
        "api_name": "Win Probability Label API",
        "student": "Student 5",
        "objective": "Give a simple explainable match-outlook label for a chasing team.",
        "endpoint": "/student5/win-probability-label",
    }


@app.post(
    "/student5/win-probability-label",
    response_model=WinProbabilityResponse,
)
def win_probability_label(payload: WinProbabilityRequest):
    return calculate_win_probability_label(payload)
